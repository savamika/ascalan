<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo app('translator')->get("languages.titles.user_page"); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('css/desktoplog.css')); ?>">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;700;800&display=swap" rel="stylesheet">
    <script src="<?php echo e(asset('js/javascript.js')); ?>"></script>
</head>
<body>
    <div class="background">
        <div class="overlay"></div>
        <div class="content">
            <div class="main-container">
                <div class="content-box">
                    <div class="close-button" onclick="closeContentBox()">X</div>
                    <div class="pops">
                        <div class="checkmark-circle">
                            <img src="<?php echo e(asset('images/tickmark.svg')); ?>";>
                        </div>
                        <span class="successful"><?php echo app('translator')->get("languages.notif.login_success"); ?></span>
                    </div>
                </div>
                <div class="rounded-rectangle">
            <div class="navigation-container">
                <div class="esaton">
                <img class="esaton-icon" src="<?php echo e(asset('images/esaton.svg')); ?>" alt="ESATON Icon">

                <div class="buttonis">
                <div class="cancel-button-container">
                    <button class="button cancel-button" onclick=""><?php echo app('translator')->get("languages.buttons.setting"); ?></button>
                </div>

                <div class="header">
                    <button class="button log-out-button" onclick="location.href='/'"><?php echo app('translator')->get("languages.buttons.logout"); ?></button>
                </div>

                </div>

            </div>



            <p class="lorem">
                <b><?php echo app('translator')->get("languages.informations.members_invited"); ?>:</b> 0 <br>
                <b><?php echo app('translator')->get("languages.informations.bonus_point"); ?>:</b> 0<br>
                <b><?php echo app('translator')->get("languages.informations.referral_code"); ?>:</b> HSiuq1842<br>

            </p>

            </div>

            <div class="chat-box">
                <label for="chat-toggle" class="chat-header"><?php echo app('translator')->get("languages.chats.title"); ?> </label>
                <div class="chat-content">
                    <div class="message received">
                        <p><?php echo app('translator')->get("languages.chats.cov1"); ?></p>
                    </div>
                    <div class="message sent">
                        <p><?php echo app('translator')->get("languages.chats.cov2"); ?></p>
                    </div>
                    <!-- Placeholder for additional messages -->
                    <div class="chat-input-container">
                        <textarea class="chat-input" placeholder="<?php echo app('translator')->get("languages.chats.type"); ?>"></textarea>
                        <button class="send-button"><?php echo app('translator')->get("languages.buttons.send"); ?></button>
                    </div>
                </div>
            </div>

    </div>
            </div>
        </div>
    </div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\ascalan\resources\views\users\home.blade.php ENDPATH**/ ?>